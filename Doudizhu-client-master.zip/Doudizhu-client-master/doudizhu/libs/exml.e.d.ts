declare class test extends eui.Skin{
}
