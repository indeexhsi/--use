/**
 * Created by WinAsia on 2017/6/15.
 */
/*消息码*/
const commands = {
    SYSTEM_MSG:1,
    REGISTER:2,
    LOGIN:3,
    MATCH_PLAYER:4,
    PLAY_GAME:5,
    ROOM_NOTIFY:6,
    PLAYER_PLAYCARD:7,
    PLAYER_WANTDIZHU:8,
    WS_CLOSE:9
};

module.exports = commands;